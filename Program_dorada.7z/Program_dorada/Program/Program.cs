﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PersonLibrary;


namespace Program
{
    class Program
    {

		
		private static Gender gender;
        private static List<Person> _persons = new List<Person>();
        
        public static void PrintAll()
        {
            foreach (var item in _persons)
            {
                item.ToString();
            }
        }
        public static void DeletePerson(long JMBG)
        {
            Person p = null;
            foreach (var item in _persons)
            {
                if (item.JMBG == JMBG)
                {
                    p = item;
                    break;
                }
            }
            if(p != null)
            {
                _persons.Remove(p);
                Console.WriteLine("Obrisana je osoba sa JMBG om: {0}", JMBG);
            }
            
        }
        public static void EditPerson(long JMBG)
        {
            Person p = null;
            foreach (var item in _persons)
            {
                if (item.JMBG == JMBG)
                {
                    p = item;
                    break;
                }
            }
            if (p != null)
            {
                Console.Write("Input name: ");
                string name = Console.ReadLine();
                Console.Write("Input last name: ");
                string lastName = Console.ReadLine();
                p.FirstName = name;
                p.LastName = lastName;
            }
            


        }

		static void Main(string[] args)
        {
            Person person = new Person("Zoran","Govedar", Gender.Male, 1905984850073, 1984, 5, 19);
            _persons.Add(person);
			int input;
            long JMBG;
			
            do
            {
                Console.WriteLine("Izaberite opciju:");
                Console.WriteLine("1.Unesite podatke nove osobe");
                Console.WriteLine("2.Ispisite podatke postojece osobe");
                Console.WriteLine("3.Izadjite iz programa");
                Console.WriteLine("4.Ispisi sve osobe");
                Console.WriteLine("5.Obrisi osobu");
                Console.WriteLine("6.Izmeni osobu");

                if (!int.TryParse(Console.ReadLine(), out input))
                {
                    Console.WriteLine("Neispavan unos.");
                }

                if (input == 1)
                {
                    Console.Write("Input name: ");
                    string name = Console.ReadLine();
                    Console.Write("Input last name: ");
                    string lastName = Console.ReadLine();
                    string jmbg;
                    string gen;
                    string birthYearStr;
                    int birthYear;
                    string birthMonthStr;
                    int birthMonth; 
                    string birthDayStr;
                    int birthDay;
					
					do
                    {
                        Console.Write("Input JMBG: ");
                        jmbg = Console.ReadLine();
                    }
                    while (!long.TryParse(jmbg, out JMBG));

                    do
                    {
                        Console.Write("Input your gender (M/F): ");
                        gen = Console.ReadLine();
                    }
                    while (gen != "M" && gen != "F");

                    do
                    {
                        Console.Write("Input birth year: ");
                        birthYearStr = Console.ReadLine();
                    }
                    while (!Int32.TryParse(birthYearStr, out birthYear) || birthYear < 1 || birthYear > DateTime.Today.Year);                    

                    

                    do
                    {
                        Console.Write("Input birth month: ");
                        birthMonthStr = Console.ReadLine();
                    }
                    while (!Int32.TryParse(birthMonthStr, out birthMonth) || birthMonth < 1 || birthMonth > 12);                    

                    do
                    {
                        Console.Write("Input birth day: ");
                        birthDayStr = Console.ReadLine();
                    }
                    while (!Int32.TryParse(birthDayStr, out birthDay) || birthDay < 1 || birthDay > DateTime.DaysInMonth(birthYear, birthMonth));

					//Gender gender = gen == "M" ? Gender.Male : Gender.Female;
					
					if (gen == "M")
					{
						 gender = Gender.Male;
					}

					if (gen == "F")
					{
						 gender = Gender.Female;
					}

					//Person person = new Person(name, lastName, gender, JMBG, birthYear, birthMonth, birthDay);

                    bool contains = false;
                    foreach (var item in _persons)
                    {
                        if (item.JMBG == person.JMBG)
                        {
                            contains = true;
                            break;
                        }
                    }

                    if (contains)
                    { 
                        Console.WriteLine("Person already exist.");
                    }
                    else
                    {
                        _persons.Add(person);
                    }

                }
                if (input == 2)
                {
                    string jmbg;
                    bool contains = false;
                    do
                    {
                        Console.Write("Input JMBG: ");
                        jmbg = Console.ReadLine();
                    }
                    while (!long.TryParse(jmbg, out JMBG));

                    foreach (var item in _persons)
                    {
                        if (item.JMBG == JMBG)
                        {
                            contains = true;
                            item.PrintPerson();
                            break;
                        }
                    }
                    
                    if (!contains)
                    {
                        Console.WriteLine("Person with that JMBG doesn't exist!");
                    }
                }
                if (input == 4)
                {
                    PrintAll();
                }

                if (input == 5)
                {

                    string jmbg;
                    do
                    {
                        Console.Write("Input JMBG: ");
                        jmbg = Console.ReadLine();
                    }
                    while (!long.TryParse(jmbg, out JMBG));
                    DeletePerson(JMBG);
                }

                if (input == 6)
                {
                    string jmbg;
                    do
                    {
                        Console.Write("Input JMBG: ");
                        jmbg = Console.ReadLine();
                    }
                    while (!long.TryParse(jmbg, out JMBG));
                    EditPerson(JMBG);

                }


            }
            while (input != 3);            
        }
    }
}
