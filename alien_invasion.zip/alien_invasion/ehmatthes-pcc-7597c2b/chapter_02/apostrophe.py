message = "One of Python's strengths is its diverse community."
print(message)
