﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CompanySystem;

namespace CompanyManager
{
    public partial class ManagerForm : Form
    {
        public ManagerForm()
        {
            InitializeComponent();

           
        }

        private void LoadProjects()
        {
            //Manager manager = new Manager();
            listProjects.Items.Clear();
            foreach (var item in Manager.Projects)
            {
                listProjects.Items.Add(item);
            }
        }

        private void onClickAddNew(object sender, EventArgs e)
        {
            var projectDlg = new ProjectDlg();
            projectDlg.ShowDialog();
        }
    }
}
