﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CompanySystem;

namespace CompanyManager
{
    public partial class SignIn : Form
    {
        public SignIn()
        {
            InitializeComponent();
        }

        private void OnSelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void OnClickSignUp(object sender, EventArgs e)
        {
            var SignUp = new SignUp();
            SignUp.ShowDialog();

            
        }

        private void onClickLogIn(object sender, EventArgs e)
        {
            var Main = new Main();

            User user;   
            if(!Master.Instance.Users.TryGetValue(textBoxUsername.Text, out user))
            {
                MessageBox.Show("User sa unetim kredencijalima ne postoji u evidenciji!");
            }
            else if (textBoxUsername.Text == user.Username && textBoxPassword.Text == user.Password)
            {
                Master.Instance.curentUser = user;
            }
            
        }
    }
}
