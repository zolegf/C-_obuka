﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CompanySystem;

namespace CompanyManager
{
    public partial class DlgDepartment : Form
    {
        public DlgDepartment()
        {
            InitializeComponent();

            foreach (var item in Master.Instance.Users)
            {
                if (item is Admin)
                    continue;

                listEmployees.Items.Add(item);
            }
        }

        private void onAddToDepartmentClick(object sender, EventArgs e)
        {
            listDepartmentEmployees.Items.Add(listEmployees.SelectedItem);
        }

        private void OnUsersIndexChanged(object sender, EventArgs e)
        {
            btnAddToDepartment.Enabled = listEmployees.SelectedItem != null;
        }

        private void onClickOK(object sender, EventArgs e)
        {
            // 1. kreiras novi departman
            var newDepartment = new Department(Master.Instance.NextObjectId);

            // 2. dodelis mu naziv i description iz tekstboxova
            newDepartment.Name = txtDepartmentName.Text;
            newDepartment.Description = txtDepartmentDescription.Text;

            // 3. za svaki employee iz liste "DepartmentEmployees"
            foreach (var item in listDepartmentEmployees.Items)
            {
                // 1. Ukloni tog employeea iz njegovog departmana
                var user = (User)item;

                user.Department.Employees.Remove(user);
                
                // 3. Spisku employeeja novog departmana kreiranog u tacki 1 dodaj employee-ja.
                newDepartment.Employees.Add(user);

                // 2. Dodeli mu novi departman kreiran u tacki 1.
                user.Department = newDepartment;

            }

            Master.Instance.Departments.Add(newDepartment);
            Master.Instance.SaveChanges();

            DialogResult = DialogResult.OK;
            

        }
    }
}
