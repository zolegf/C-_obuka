﻿namespace CompanyManager
{
    partial class ManagerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listProjects = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupState = new System.Windows.Forms.GroupBox();
            this.radioDelay = new System.Windows.Forms.RadioButton();
            this.radioFinished = new System.Windows.Forms.RadioButton();
            this.radioInProgress = new System.Windows.Forms.RadioButton();
            this.radioNew = new System.Windows.Forms.RadioButton();
            this.textManager = new System.Windows.Forms.TextBox();
            this.textDescription = new System.Windows.Forms.TextBox();
            this.textEndDate = new System.Windows.Forms.TextBox();
            this.textStartDate = new System.Windows.Forms.TextBox();
            this.textTitle = new System.Windows.Forms.TextBox();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnAddNew = new System.Windows.Forms.Button();
            this.listTasks = new System.Windows.Forms.ListBox();
            this.label7 = new System.Windows.Forms.Label();
            this.groupState.SuspendLayout();
            this.SuspendLayout();
            // 
            // listProjects
            // 
            this.listProjects.FormattingEnabled = true;
            this.listProjects.Location = new System.Drawing.Point(60, 25);
            this.listProjects.Name = "listProjects";
            this.listProjects.Size = new System.Drawing.Size(120, 108);
            this.listProjects.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(60, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Project List";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 273);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Manager";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(0, 224);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Description";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 201);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "End Date";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(5, 175);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 12;
            this.label2.Text = "Start Date";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(33, 150);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(27, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Title";
            // 
            // groupState
            // 
            this.groupState.Controls.Add(this.radioDelay);
            this.groupState.Controls.Add(this.radioFinished);
            this.groupState.Controls.Add(this.radioInProgress);
            this.groupState.Controls.Add(this.radioNew);
            this.groupState.Location = new System.Drawing.Point(60, 296);
            this.groupState.Name = "groupState";
            this.groupState.Size = new System.Drawing.Size(111, 116);
            this.groupState.TabIndex = 8;
            this.groupState.TabStop = false;
            this.groupState.Text = "State";
            // 
            // radioDelay
            // 
            this.radioDelay.AutoSize = true;
            this.radioDelay.Location = new System.Drawing.Point(7, 85);
            this.radioDelay.Name = "radioDelay";
            this.radioDelay.Size = new System.Drawing.Size(52, 17);
            this.radioDelay.TabIndex = 0;
            this.radioDelay.Text = "Delay";
            this.radioDelay.UseVisualStyleBackColor = true;
            // 
            // radioFinished
            // 
            this.radioFinished.AutoSize = true;
            this.radioFinished.Location = new System.Drawing.Point(7, 62);
            this.radioFinished.Name = "radioFinished";
            this.radioFinished.Size = new System.Drawing.Size(64, 17);
            this.radioFinished.TabIndex = 0;
            this.radioFinished.Text = "Finished";
            this.radioFinished.UseVisualStyleBackColor = true;
            // 
            // radioInProgress
            // 
            this.radioInProgress.AutoSize = true;
            this.radioInProgress.Location = new System.Drawing.Point(7, 39);
            this.radioInProgress.Name = "radioInProgress";
            this.radioInProgress.Size = new System.Drawing.Size(75, 17);
            this.radioInProgress.TabIndex = 0;
            this.radioInProgress.Text = "InProgress";
            this.radioInProgress.UseVisualStyleBackColor = true;
            // 
            // radioNew
            // 
            this.radioNew.AutoSize = true;
            this.radioNew.Checked = true;
            this.radioNew.Location = new System.Drawing.Point(7, 16);
            this.radioNew.Name = "radioNew";
            this.radioNew.Size = new System.Drawing.Size(47, 17);
            this.radioNew.TabIndex = 0;
            this.radioNew.TabStop = true;
            this.radioNew.Text = "New";
            this.radioNew.UseVisualStyleBackColor = true;
            // 
            // textManager
            // 
            this.textManager.Location = new System.Drawing.Point(60, 270);
            this.textManager.Name = "textManager";
            this.textManager.Size = new System.Drawing.Size(100, 20);
            this.textManager.TabIndex = 3;
            // 
            // textDescription
            // 
            this.textDescription.Location = new System.Drawing.Point(60, 224);
            this.textDescription.Multiline = true;
            this.textDescription.Name = "textDescription";
            this.textDescription.Size = new System.Drawing.Size(223, 40);
            this.textDescription.TabIndex = 4;
            // 
            // textEndDate
            // 
            this.textEndDate.Location = new System.Drawing.Point(60, 198);
            this.textEndDate.Name = "textEndDate";
            this.textEndDate.Size = new System.Drawing.Size(100, 20);
            this.textEndDate.TabIndex = 5;
            // 
            // textStartDate
            // 
            this.textStartDate.Location = new System.Drawing.Point(60, 172);
            this.textStartDate.Name = "textStartDate";
            this.textStartDate.Size = new System.Drawing.Size(100, 20);
            this.textStartDate.TabIndex = 6;
            // 
            // textTitle
            // 
            this.textTitle.Location = new System.Drawing.Point(60, 146);
            this.textTitle.Name = "textTitle";
            this.textTitle.Size = new System.Drawing.Size(100, 20);
            this.textTitle.TabIndex = 7;
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(60, 436);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(87, 23);
            this.btnEdit.TabIndex = 14;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseVisualStyleBackColor = true;
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(153, 436);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(87, 23);
            this.btnDelete.TabIndex = 14;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            // 
            // btnAddNew
            // 
            this.btnAddNew.Location = new System.Drawing.Point(246, 436);
            this.btnAddNew.Name = "btnAddNew";
            this.btnAddNew.Size = new System.Drawing.Size(87, 23);
            this.btnAddNew.TabIndex = 14;
            this.btnAddNew.Text = "Add New";
            this.btnAddNew.UseVisualStyleBackColor = true;
            this.btnAddNew.Click += new System.EventHandler(this.onClickAddNew);
            // 
            // listTasks
            // 
            this.listTasks.FormattingEnabled = true;
            this.listTasks.Location = new System.Drawing.Point(186, 25);
            this.listTasks.Name = "listTasks";
            this.listTasks.Size = new System.Drawing.Size(120, 108);
            this.listTasks.TabIndex = 0;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(183, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "Task List";
            // 
            // ManagerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(423, 533);
            this.Controls.Add(this.btnAddNew);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.groupState);
            this.Controls.Add(this.textManager);
            this.Controls.Add(this.textDescription);
            this.Controls.Add(this.textEndDate);
            this.Controls.Add(this.textStartDate);
            this.Controls.Add(this.textTitle);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listTasks);
            this.Controls.Add(this.listProjects);
            this.Name = "ManagerForm";
            this.Text = "ManagerForm";
            this.groupState.ResumeLayout(false);
            this.groupState.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listProjects;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupState;
        private System.Windows.Forms.RadioButton radioDelay;
        private System.Windows.Forms.RadioButton radioFinished;
        private System.Windows.Forms.RadioButton radioInProgress;
        private System.Windows.Forms.RadioButton radioNew;
        private System.Windows.Forms.TextBox textManager;
        private System.Windows.Forms.TextBox textDescription;
        private System.Windows.Forms.TextBox textEndDate;
        private System.Windows.Forms.TextBox textStartDate;
        private System.Windows.Forms.TextBox textTitle;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnAddNew;
        private System.Windows.Forms.ListBox listTasks;
        private System.Windows.Forms.Label label7;
    }
}