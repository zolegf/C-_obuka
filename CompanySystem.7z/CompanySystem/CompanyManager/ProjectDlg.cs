﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CompanySystem;

namespace CompanyManager
{
    public partial class ProjectDlg : Form
    {
        public ProjectDlg()
        {
            InitializeComponent();
        }

        private void onClickOK(object sender, EventArgs e)
        {

            Projects project = new Projects();
            project.Title = textTitle.Text;
            project.StartDate = dateStartDate.Value;
            project.EndDate = dateEndDate.Value;
            project.Description = textDescription.Text;
            if (radioNew.Checked == true)
            {
                project.State = ProjectState.New;
            }
            else if(radioInProgress.Checked == true)
            {
                project.State = ProjectState.InProgress;
            }
            else if(radioFinished.Checked == true)
            {
                project.State = ProjectState.Finished;
            }

            Master.Instance.Projects.Add(project);

            Master.Instance.SaveChanges();

            DialogResult = DialogResult.OK;
        }
    }
}
