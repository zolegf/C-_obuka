﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompanySystem
{
    public enum ProjectState
    {
        New,
        InProgress,
        Finished,
        Delay
    }
    [Serializable]
    public class Projects
    {
        public string Title { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Description { get; set; }
        public ProjectState State { get; set; }
    }
}
