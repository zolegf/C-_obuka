﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompanySystem
{
    [Serializable]
    public class Manager : User
    {
        public static List<Projects> Projects { get; set; } = new List<Projects>();


        public Manager(int id) : base(id)
        {

        }


    }
}
