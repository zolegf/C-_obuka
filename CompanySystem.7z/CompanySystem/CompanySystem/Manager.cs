﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompanySystem
{
    [Serializable]
    public class Manager : User
    {
        private int id;
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public Department Department { get; set; }

        public int Id
        {
            get { return id; }
        }

        public Manager() : base ()
        {
        }

        public void CreateProject()
        {
            //TODO
        }

        public void EditProject()
        {
            //TODO
        }

        public void DeleteProject()
        {
            //TODO
        }

        public void CreateTask()
        {
            //TODO
        }

        
        public List<Task> GetTasks()
        {
            //TODO
            return null;
        }

        public void SetProjectState()
        {
            //TODO
            
        }

    }
}
