﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace CompanySystem
{
    [Serializable]
    public sealed class Master
    {
        private const string CompanyFile = "c:\\Data\\Data.bin";
        private static Master _master;
        public int LastId { get; set; }
        public List<Department> Departments { get; set; } = new List<Department>();
        public List<Projects> Projects { get; set; } = new List<Projects>();
        public List<Task> Tasks { get; set; } = new List<Task>();
        public List<Employee> Employees { get; set; } = new List<Employee>();
        public List<Manager> Managers { get; set; } = new List<Manager>();
        public List<User> Users { get; set; } = new List<User>();
        public User curentUser { get; set; }

        private Master()
        {
            Users.Add(new Admin(NextObjectId, "admin", "admin", "admin", "admin"));

            Departments.AddRange(new[]
            {
                new Department(NextObjectId) { Name = "Accounting", Description = "Taking care about some bullshit..." },
                new Department(NextObjectId) { Name = "Production", Description = "Making bullshit and enjoying it." },
                new Department(NextObjectId) { Name = "Marketing", Description = "Convincig people to buy some bullshit..." },
                new Department(NextObjectId) { Name = "Sales", Description = "Seling bullshit to people..." },
            });
        }

        private static Master Load()
        {

            if (!File.Exists(CompanyFile))
            {
                return new Master();
            }
            else
            {

                using (var stream = File.Open(CompanyFile, FileMode.Open))
                {
                    var formatter = new BinaryFormatter();
                    return (Master)formatter.Deserialize(stream);
                }
            }
        }

        public static Master Instance
        {
            get
            {
                if (_master == null)
                {
                    _master = Load();
                    _master.SaveChanges();
                }

                return _master;
            }

        }

        public void SaveChanges()
        {

            using (FileStream stream = new FileStream(CompanyFile, FileMode.Create))
            {
                var formatter = new BinaryFormatter();
                formatter.Serialize(stream, this);
            }
        }

        public void AddUser(User user)
        {
            Users.Add(user);
            if (user is Manager)
            {
                Manager manager = new Manager(NextObjectId);
                Managers.Add(manager);

            }
            else if (user is Employee)
            {

            }
        }

        public void CreateProject()
        {
            //TODO
        }

        public void EditProject()
        {
            //TODO
        }

        public void DeleteProject()
        {
            //TODO
        }

        public void CreateTask()
        {
            //TODO
        }


        public List<Task> GetTasks()
        {
            //TODO
            return null;
        }

        public void SetProjectState()
        {
            //TODO

        }

        public int NextObjectId
        {
            get { return ++LastId; }
        }
    }
}
