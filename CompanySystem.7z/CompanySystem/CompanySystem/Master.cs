﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace CompanySystem
{
    [Serializable]
    public sealed class Master
    {
        private int id = 0;

        private static int nextObjectId = 0;

        private const string CompanyFile = "c:\\Data\\Data.bin";
        private static Master _master { get; set; }
        public List<Department> Departments { get; set; } = new List<Department>();
        public List<Projects> Projects { get; set; } = new List<Projects>();
        public List<Task> Tasks { get; set; } = new List<Task>();
        public Dictionary<string, Employee> Employees { get; set; } = new Dictionary<string, Employee>();
        public Dictionary<string, Manager> Managers { get; set; } = new Dictionary<string, Manager>();
        public Dictionary<string, User> Users { get; set; } = new Dictionary<string, User>();
        public User curentUser { get; set; }

       

        private Master ()
        {
            Admin a = new Admin("admn", "admn", "admin", "admin");
            Users.Add(a.Username, a);
        }

        private static void Load()
        {

            if (!File.Exists(CompanyFile))
            {
                _master = new Master();
                _master.SaveChanges();
            }
            else
            {
                
                using (var stream = File.Open(CompanyFile, FileMode.Open))
                {
                    var formatter = new BinaryFormatter();
                    _master = (Master)formatter.Deserialize(stream);
                }
                
            }
        }

        public static Master Instance
        {
            get
            {
                if (_master == null)
                {
                    Load();
                }

                return _master;
            }

        }

        

        public void SaveChanges()
        {
            
            using (FileStream stream = new FileStream(CompanyFile, FileMode.Create))
            {
                var formatter = new BinaryFormatter();
                formatter.Serialize(stream, _master);
            }
        }

        public void AddUser(User user)
        {
            Users.Add(user.Username, user);
            if(user is Manager)
            {
                Manager manager = new Manager();
                Managers.Add(manager.FirstName, manager);

            }
            else if (user is Employee)
            {

            }
        }

        

        public void AddEmployee(Employee e)
        {
           // Employees.Add(e.Id, e);
        }
        
        public List<Projects> GetProjects()
        {
            //TODO
            return null;
        }

        public List<Manager> GetManagers()
        {
            //TODO
            return null;
        }

        public void AddDepartment()
        {
            //TOD
        }

        public void EditDepartment()
        {
            //TOD
        }

        public void DeleteDepartment()
        {
            //TOD
        }

        public void PromoteEmployee()
        {
            //TODO
        }

        public List<Employee> GetAllEmployees()
        {
            //TODO
            return null;
        }

        public void EditEmployee()
        {
            //TODO
        }

        public static int NextObjectId
        {
            get
            {
                return ++nextObjectId;
            }
        }
    }
}
