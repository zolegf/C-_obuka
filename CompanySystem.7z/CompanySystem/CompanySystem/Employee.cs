﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompanySystem
{
    [Serializable]
    public class Employee : User
    {
        public Employee(int id): base(id)
        {

        }

    }
}
