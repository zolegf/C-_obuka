﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompanySystem
{
    [Serializable]
    public class User
    {
        public int Id { get; private set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public Department Department { get; set; }

        public User(int id)
        {
            Id = id;
        }

        public override string ToString()
        {
            return $"{FirstName} {LastName}";
        }

        public override bool Equals(object obj)
        {
            return obj is User && (obj as User).Id == Id;
        }

        public override int GetHashCode() // ==> 123456
        {
            return Id.GetHashCode();
        }

        // ako a.Equals(b) then a.GetHashCode() == b.GetHashCode();
    }
}
