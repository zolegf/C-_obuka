﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompanySystem
{
    [Serializable]
    public class User
    {
        private int id;
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public Department Department { get; set; }
        

        public int Id
        {
            get { return id; }
        }

        public User()
        {
            id = Master.NextObjectId;
        }
        
    }
}
