﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompanySystem
{
    [Serializable]
    public class Admin : User
    {
        public Admin(string firstName, string lastName, string username, string password)  
        {
            FirstName = firstName;
            LastName = lastName;
            Username = username;
            Password = password;
            
        }
    }
}
