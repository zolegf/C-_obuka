﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shape
{
    static class PrintShape
    {
        

        public static void print(IShape shape)
        {
            shape.Area();
            shape.Diameter();
            string s = shape.ShapeType;
            Console.WriteLine("Type:{0} ,\nDiameter : {1},\nArea : {2}  ",s,shape.Area(),shape.Diameter());

        }

    }
}
