﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shape
{
    interface IShape
    {
        double Diameter();
        double Area();
        string ShapeType { get; }

    }

    class Program
    {
        static void Main(string[] args)
        {
            IShape cyrcle = new Cyrcle(2.0, 3.14, "Krug");
            IShape square = new Square(5.0, "Kvadrat");
            IShape triangle = new Triangle(2.0, 5.0, "Trougao");

            PrintShape.print(cyrcle);
            Console.WriteLine("____________");
            Console.WriteLine();
            
            PrintShape.print(square);
            Console.WriteLine("____________");
            Console.WriteLine();
            PrintShape.print(triangle);

            Console.ReadLine();
            
        }

    }

    class Cyrcle : IShape
    {
        private double _radius;
        private double _pi;
        private string _shape;

        public string ShapeType
        {
            get
            {
                return _shape;
            }
        }

        public Cyrcle(double rad, double pi, string shape)
        {
            _radius = rad;
            _pi = pi;
            _shape = shape;
        }

        public double Diameter()
        {
            return _radius * _pi;

        }

        public double Area()
        {
            return _radius * _radius * _pi;
        }


    }

    class Square : IShape
    {
        private double _a;
        private string _shape;

        public Square(double a, string shape)
        {
            _a = a;
            _shape = shape;
        }

        public string ShapeType
        {
            get
            {
                return _shape;
            }
        }

        public double Diameter()
        {
            return 4 * _a;

        }

        public double Area()
        {
            return _a * _a;
        }

        

    }

    class Triangle : IShape
    {
        private double _a;
        private double _h;
        private string _shape;

        public Triangle(double a, double h, string shape)
        {
            _a = a;
            _h = h;
            _shape = shape;
        }


        public string ShapeType
        {
            get
            {
                return _shape;
            }
        }

        public double Diameter()
        {
            return 3 * _a;
        }

        public double Area()
        {
            return _a * _h;
        }

        

    }
}
