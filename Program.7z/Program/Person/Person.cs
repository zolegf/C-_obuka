﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonLibrary
{
    [Serializable]
    public class Person
    {
        private string firstName;
        private string lastName;
        public Gender gender;
        private long jmbg;
        DateTime bDay;
        private int age;

        public Person(string firstName, string lastName, Gender gender, long jmbg, int year, int month, int day)
        {
            this.firstName = firstName;
            this.lastName = lastName;
            this.gender = gender;
            this.jmbg = jmbg;
            this.bDay = new DateTime(year, month, day);
        }

        public string Name
        {
            get
            {
                return firstName;
            }

            set
            {
                firstName = value;
            }
        }

        public long JMBG
        {
            get
            {
                return jmbg;
            }
        }

        public int Age
        {
            get
            {
                int todayYear = DateTime.Today.Year;
                int bDayYear = bDay.Year;
                age = todayYear - bDayYear;
                return age;

            }
        }

        public int NumDays()
        {
            TimeSpan t = new DateTime(DateTime.Today.Year, bDay.Month, bDay.Day) - DateTime.Today;
            int numberOfDays = (int)t.TotalDays;
            if (numberOfDays < 0)
                numberOfDays += DateTime.IsLeapYear(DateTime.Today.Year) ? 366 : 365;

            return numberOfDays;

        }

        public bool LeapYear()
        {
            if (DateTime.IsLeapYear(bDay.Year))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public override string ToString()
        {
            this.PrintPerson();
            return string.Empty;
        }

        public void PrintPerson()
        {
            Console.WriteLine("-----------------------------------------------------------");
            Console.WriteLine("My name is: {0} {1}", firstName, lastName);
            Console.WriteLine("JMBG: {0}", JMBG);
            Console.WriteLine("My gender is: {0}", gender);
            Console.WriteLine("My age is: {0}", Age);
            Console.WriteLine("My birthday is for: {0} days", this.NumDays());
            Console.WriteLine("Birth year leap or not: {0}", this.LeapYear());
            Console.WriteLine("===========================================================");
        }




    }


}
