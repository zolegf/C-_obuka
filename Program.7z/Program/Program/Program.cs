﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PersonLibrary;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Program
{
    class Program
    {
        
        private static List<Person> _persons = new List<Person>();
        private static void DeletePerson(long JMBG)
        {
            Person p = null;
            foreach (var item in _persons)
            {
                if (item.JMBG == JMBG)
                {
                    p = item;

                }
            }
            _persons.Remove(p);
            Console.WriteLine("Osoba sa JMBG om: {0}, je obrisana iz kolekcije!", JMBG);

        }
        private static void EditName(long JMBG, string name)
        {
            Person p = null;
            foreach (var item in _persons)
            {
                if (item.JMBG == JMBG)
                {
                    p = item;

                }
            }
            p.Name = name;
        }

        static void Main(string[] args)
        {
            BinaryFormatter formatter = new BinaryFormatter();

            using (FileStream stream = new FileStream("C:/data/data.bin", FileMode.Open))
            {
                
                _persons = (List<Person>)formatter.Deserialize(stream);
            }
                
            //stream.Close();

            int input;
            long JMBG;
            do
            {
                Console.WriteLine("Izaberite opciju:");
                Console.WriteLine("1.Unesite podatke nove osobe");
                Console.WriteLine("2.Ispisite podatke postojece osobe");
                Console.WriteLine("3.Izadjite iz programa");
                Console.WriteLine("4.Obrisi osobu");
                Console.WriteLine("5.Promeni ime osobe");
                Console.WriteLine("6.Ispisi sve osobe iz kolekcije");


                if (!int.TryParse(Console.ReadLine(), out input))
                {
                    Console.WriteLine("Neispavan unos.");
                }

                if (input == 1)
                {
                    Console.Write("Unesite ime: ");
                    string ime = Console.ReadLine();
                    Console.Write("Unesite prezime: ");
                    string prezime = Console.ReadLine();
                    string jmbg;

                    string pol;
                    string birthYearStr;
                    int birthYear;
                    string birthMonthStr;
                    int birthMonth;
                    string birthDayStr;
                    int birthDay;
                    do
                    {
                        Console.Write("Unesite JMBG: ");
                        jmbg = Console.ReadLine();
                    }
                    while (!long.TryParse(jmbg, out JMBG));

                    do
                    {
                        Console.Write("Unesite kog ste pola (M/F): ");
                        pol = Console.ReadLine();
                    }
                    while (pol != "M" && pol != "F");

                    do
                    {
                        Console.Write("Unesite godinu rodjenja: ");
                        birthYearStr = Console.ReadLine();
                    }
                    while (!Int32.TryParse(birthYearStr, out birthYear) || birthYear < 1 || birthYear > DateTime.Today.Year);                    

                    

                    do
                    {
                        Console.Write("Unesite mesec rodjenja: ");
                        birthMonthStr = Console.ReadLine();
                    }
                    while (!Int32.TryParse(birthMonthStr, out birthMonth) || birthMonth < 1 || birthMonth > 12);                    

                    do
                    {
                        Console.Write("Unesite dan rodjenja: ");
                        birthDayStr = Console.ReadLine();
                    }
                    while (!Int32.TryParse(birthDayStr, out birthDay) || birthDay < 1 || birthDay > DateTime.DaysInMonth(birthYear, birthMonth));
                    ///
                    Gender gender = pol == "M" ? Gender.Male : Gender.Female;

                    Person person = new Person(ime, prezime, gender, JMBG, birthYear, birthMonth, birthDay);
                    

                    bool contains = false;
                    foreach (var item in _persons)
                    {
                        if (item.JMBG == person.JMBG)
                        {
                            contains = true;
                            break;
                        }
                    }

                    if (contains)
                    { 
                        Console.WriteLine("Osoba se vec nalazi na listi.");
                    }
                    else
                    {
                        _persons.Add(person);
                    }
                    SaveChanges();

                }
                if (input == 2)
                {
                    string jmbg;
                    bool contains = false;
                    do
                    {
                        Console.Write("Unesite JMBG: ");
                        jmbg = Console.ReadLine();
                    }
                    while (!long.TryParse(jmbg, out JMBG));

                    foreach (var item in _persons)
                    {
                        if (item.JMBG == JMBG)
                        {
                            contains = true;
                            
                            item.PrintPerson();
                            break;
                        }
                    }

                    if (!contains)
                    {
                        Console.WriteLine("Osoba sa takvim JMBG-om ne postoji u evidenciji!");
                    }
                }
                if (input == 4)
                {
                    string jmbg;
                    
                    bool contains = false;
                    do
                    {
                        Console.Write("Unesite JMBG: ");
                        jmbg = Console.ReadLine();
                    }
                    while (!long.TryParse(jmbg, out JMBG));

                    foreach (var item in _persons)
                    {
                        if (item.JMBG == JMBG)
                        {
                            contains = true;
                            break;
                        }
                    }

                    if (!contains)
                    {
                        Console.WriteLine("Osoba sa takvim JMBG-om ne postoji u evidenciji!");
                    }
                    DeletePerson(JMBG);
                    SaveChanges();

                }
                if (input == 5)
                {
                    string jmbg;
                    string ime;
                    bool contains = false;
                    do
                    {
                        Console.Write("Unesite JMBG: ");
                        jmbg = Console.ReadLine();
                    }
                    while (!long.TryParse(jmbg, out JMBG));

                    foreach (var item in _persons)
                    {
                        if (item.JMBG == JMBG)
                        {
                            contains = true;
                            break;
                        }
                    }

                    if (!contains)
                    {
                        Console.WriteLine("Osoba sa takvim JMBG-om ne postoji u evidenciji!");
                    }
                    else
                    {
                        Console.Write("Unesite novo ime: ");
                        ime = Console.ReadLine();

                        EditName(JMBG, ime);
                        SaveChanges();
                    }

                }
                if (input == 6)
                {
                    foreach (var item in _persons)
                    {
                        item.ToString();
                    }
                }

            }
            while (input != 3);
                            
        }

        private static void SaveChanges()
        {
            using (FileStream stream = new FileStream("C:/data/data.bin", FileMode.Create))
            {
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(stream, _persons);
                stream.Close();
            }
        }
    }
}
